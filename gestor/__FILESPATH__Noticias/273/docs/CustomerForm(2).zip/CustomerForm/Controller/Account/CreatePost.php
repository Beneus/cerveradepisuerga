<?php

namespace Datadial\CustomerForm\Controller\Account;

use Magento\Customer\Model\Account\Redirect as AccountRedirect;
use Magento\Customer\Api\Data\AddressInterface;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Action\Context;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Exception\LocalizedException;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Api\AccountManagementInterface;
use Magento\Customer\Helper\Address;
use Magento\Framework\UrlFactory;
use Magento\Customer\Model\Metadata\FormFactory;
use Magento\Newsletter\Model\SubscriberFactory;
use Magento\Customer\Api\Data\RegionInterfaceFactory;
use Magento\Customer\Api\Data\AddressInterfaceFactory;
use Magento\Customer\Api\Data\CustomerInterfaceFactory;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Customer\Model\Registration;
use Magento\Framework\Escaper;
use Magento\Customer\Model\CustomerExtractor;
use Magento\Framework\Exception\StateException;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\DataObject;

class CreatePost extends \Magento\Customer\Controller\Account\CreatePost
{
 
     /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    protected $_customTransport;

    protected $_countryFactory;
    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $inlineTranslation;
    /**
     * @param Context $context
     * @param Session $customerSession
     * @param ScopeConfigInterface $scopeConfig
     * @param StoreManagerInterface $storeManager
     * @param AccountManagementInterface $accountManagement
     * @param Address $addressHelper
     * @param UrlFactory $urlFactory
     * @param FormFactory $formFactory
     * @param SubscriberFactory $subscriberFactory
     * @param RegionInterfaceFactory $regionDataFactory
     * @param AddressInterfaceFactory $addressDataFactory
     * @param CustomerInterfaceFactory $customerDataFactory
     * @param CustomerUrl $customerUrl
     * @param Registration $registration
     * @param Escaper $escaper
     * @param CustomerExtractor $customerExtractor
     * @param DataObjectHelper $dataObjectHelper
     * @param AccountRedirect $accountRedirect
     * @param Validator $formKeyValidator
     *
     * @SuppressWarnings(PHPMD.ExcessiveParameterList)
     */
    public function __construct(
        Context $context,
        Session $customerSession,
        ScopeConfigInterface $scopeConfig,
        StoreManagerInterface $storeManager,
        AccountManagementInterface $accountManagement,
        Address $addressHelper,
        UrlFactory $urlFactory,
        FormFactory $formFactory,
        SubscriberFactory $subscriberFactory,
        RegionInterfaceFactory $regionDataFactory,
        AddressInterfaceFactory $addressDataFactory,
        CustomerInterfaceFactory $customerDataFactory,
        CustomerUrl $customerUrl,
        Registration $registration,
        Escaper $escaper,
        CustomerExtractor $customerExtractor,
        DataObjectHelper $dataObjectHelper,
        AccountRedirect $accountRedirect,
        Validator $formKeyValidator = null,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Datadial\Transport\Model\Transport $customTransport,
        \Magento\Directory\Model\CountryFactory $countryFactory
    ) {
        $this->_transportBuilder = $transportBuilder;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_customTransport = $customTransport;
        $this->_countryFactory = $countryFactory;
        parent::__construct($context,
        $customerSession,
        $scopeConfig,
        $storeManager,
        $accountManagement,
        $addressHelper,
        $urlFactory,
        $formFactory,
        $subscriberFactory,
        $regionDataFactory,
        $addressDataFactory,
        $customerDataFactory,
        $customerUrl,
        $registration,
        $escaper,
        $customerExtractor,
        $dataObjectHelper,
        $accountRedirect,
        $formKeyValidator
        );
    }


    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if (!$this->getRequest()->isPost()) {
            die('Not is Post');
            $url = $this->urlModel->getUrl('*/*/create', ['_secure' => true]);
            $resultRedirect->setUrl($this->_redirect->error($url));
            $this->messageManager->addError(__('Form wrongly submitted'));
            return $resultRedirect;
        }

        try {
           
            // var_dump($this->getRequest()->getParams());
            // exit;
            $emaildata = [];
            foreach($this->getRequest()->getParams() as $key => $value){
                if(!is_array($value)){
                    if($key == 'country_id'){
                        $value = $this->getCountryName($value);
                    }
                    $emaildata[$key] = $value;
                }else{
                    if($key == 'street'){
                        $emaildata['street0'] = $value[0];
                        $emaildata['street1'] = $value[1];
                        $emaildata['street2'] = $value[2];
                    }
                }
            }

            $recipient = $this->scopeConfig->getValue('trans_email/ident_support/email',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
            $this->sendEmail($recipient,$emaildata);
            $url = $this->urlModel->getUrl('*/*/create', ['_secure' => true]);
            $resultRedirect->setUrl($this->_redirect->success($url));
            return $resultRedirect;
        }catch(Exception $e){
            $this->messageManager->addError(__('Form wrongly submitted'));
        }  

    }

    /**
     * @param array $post Post data from contact form
     * @return void
     */
    private function sendEmail($email,$post)
    {

        
        try {

            //$post = $this->getRequest()->getPostValue();

            $subject    = 'New Customer Regitration';     
            $fromEmail  = $this->scopeConfig->getValue('trans_email/ident_support/email');  
            $fromName   = 'Support Design911';
            $from       = ['email' => $fromEmail, 'name' => $fromName];
            $to         = $this->scopeConfig->getValue('trans_email/ident_support/email');  

            $templateVars = [
                        'store' =>  $this->storeManager->getStore()->getId(),
                        'subject' => $subject,
                        'data'   => new DataObject($post)
                    ];

            $this->_inlineTranslation->suspend();
            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            $templateOptions = [
                'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                'store' => $this->storeManager->getStore()->getId()
            ];
            $transport = $this->_transportBuilder->setTemplateIdentifier('send_email_email_template', $storeScope)
                    ->setTemplateOptions($templateOptions)
                    ->setTemplateVars($templateVars)
                    ->setFrom($from)
                    ->addTo($to)               
                    ->getTransport();
            $this->_inlineTranslation->resume();
            $this->_customTransport->sendMessage();
            $this->messageManager->addSuccess(__('Form successfully submitted'));

        }catch(Exception $e){
            $this->messageManager->addError(__('Form wrongly submitted'));
        }

    }

    public function getCountryName($countryCode){    
        $country = $this->_countryFactory->create()->loadByCode($countryCode);
        return $country->getName();
    }
    
}

?>
